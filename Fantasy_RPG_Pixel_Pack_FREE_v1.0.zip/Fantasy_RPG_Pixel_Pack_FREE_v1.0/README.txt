========================================================================
FANTASY RPG & DUNGEON PIXEL ART STARTER PACK (32x32 & 48x48) - v1.0
========================================================================

Thank you for downloading this pack! Every sprite and animation strip in
this collection is aligned to a strict pixel-perfect grid (32x32 or 48x48)
with clean 1px dark outlines, 0% background halo, and ready-to-import
JSON metadata (compatible with Aseprite, Godot, Unity, and TexturePacker).

CONTENTS:
---------
1. 01_Icons_and_Rarities_32x32/
   - 18 Fantasy RPG Items across 5 Rarity/Elemental Tiers (90 sprites total!)
   - Includes both a packed Sprite-Sheet (.png + .json) and 90 individual PNGs.

2. 02_Animated_Items_32x32/
   - 8-Frame Floating, Shadow & Specular Shine animations for all 18 items
     (144 animation frames total).

3. 03_HD_Icons_and_Animations_48x48/
   - Higher-detail 48x48 versions of all 18 RPG items + 8-frame animations.

4. 04_Dungeon_Pickups_and_VFX_32x32/
   - 10 Animated 8-frame strips (80 frames total):
     * Spinning Gold & Silver Coins
     * Floating Ruby, Sapphire & Emerald Gems
     * Flickering Dungeon Fire & Cursed Void Torches
     * Ice, Fire & Arcane Void Sword Slash VFX

Enjoy making awesome games!
